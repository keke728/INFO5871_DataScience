# Teaching Evaluations dataset

## About the data

### Provenance

https://www.openintro.org/stat/data/evals.php

### Shape 

- 463 rows 
- 12 columns

### Observations

- score: Average professor evaluation score: (1) very unsatisfactory - (5) excellent.
- rank: Rank of professor: teaching, tenure track, tenured.
- ethnicity: Ethnicity of professor: not minority, minority.
- gender: Gender of professor: female, male.
- language: Language of school where professor received education: English or non-English.
- age: Age of professor.
- cls_perc_eval: Percent of students in class who completed evaluation.
- cls_did_eval: Number of students in class who completed evaluation.
- cls_students: Total number of students in class.
- cls_level: Class level: lower, upper.
- cls_profs: Number of professors teaching sections in course in sample: single, multiple.
- cls_credits: Number of credits of class: one credit (lab, PE, etc.), multi credit.
- bty_f1lower: Beauty rating of professor from lower level female: (1) lowest - (10) highest.
- bty_f1upper: Beauty rating of professor from upper level female: (1) lowest - (10) highest.
- bty_f2upper: Beauty rating of professor from second level female: (1) lowest - (10) highest.
- bty_m1lower: Beauty rating of professor from lower level male: (1) lowest - (10) highest.
- bty_m1upper: Beauty rating of professor from upper level male: (1) lowest - (10) highest.
- bty_m2upper: Beauty rating of professor from second upper level male: (1) lowest - (10) highest.
- bty_avg: Average beauty rating of professor.
- pic_outfit: Outfit of professor in picture: not formal, formal.
- pic_color: Color of professor’s picture: color, black & white.
