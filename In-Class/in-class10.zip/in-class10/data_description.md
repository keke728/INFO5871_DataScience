# Donors Choose dataset

## About the data

### Provenance

www.donorschoose.org
https://www.kaggle.com/donorschoose/io

### Shape 

Donations-2017.csv
Projects-smaller.csv
Schools.csv

### Observations

See full description on Kaggle. 