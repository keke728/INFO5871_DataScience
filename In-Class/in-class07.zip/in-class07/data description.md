# HSR Regional dataset

## About the data

This is data about health outcomes and other demographic data compiled by the Colorado Health Institute.  

### Provenance

From the Colorado Health Institute: 

[https://www.coloradohealthinstitute.org/data]


### Shape 

- Excel spreadsheet with 25 sheets

### Observations

Excel spreadsheet contains data description.





