# INFO 5871 studnet info dataset

## About the data

### Provenance

Compiled by Robin Burke, University of Colorado Boulder, 2019.

### Shape 

- 12 rows 
- 13 columns

### Observations

Student answers to questions on a start-of-class survey on the usefulness of different course topics. Personal and demographic data omitted.

### Associated documentation

[Data collection document](student-info.docx)

